import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import test from 'node:test';
import { createScannerHarness, mockResponse } from './scanner-harness.mjs';

const jobSource = {
  jobId: 'JOB-PAGES',
  jobTitle: 'Fulfillment Associate',
  locationName: 'UK Fulfillment Centre',
};

test('exactly three independent nationwide loops retain their 5s and 10s startup timing', () => {
  const trackerPath = fileURLToPath(new URL('../tracker.mjs', import.meta.url));
  const source = readFileSync(trackerPath, 'utf8');
  const configuredLoops = source.match(/runScannerLoop\('Loop-[123]'\)/g) ?? [];

  assert.equal(configuredLoops.length, 3);
  assert.equal(configuredLoops.filter((loop) => loop.includes('Loop-1')).length, 1);
  assert.equal(configuredLoops.filter((loop) => loop.includes('Loop-2')).length, 1);
  assert.equal(configuredLoops.filter((loop) => loop.includes('Loop-3')).length, 1);
  assert.match(source, /runScannerLoop\('Loop-1'\);/);
  assert.match(source, /runScannerLoop\('Loop-2'\);\s*\},\s*5000\)/);
  assert.match(source, /runScannerLoop\('Loop-3'\);\s*\},\s*10000\)/);
});

test('job feed preserves Amazon request URL, query, variables and headers', async (t) => {
  const harness = createScannerHarness(t, {
    jobResponder: async () => mockResponse({
      data: { searchJobCardsByLocation: { jobCards: [], nextToken: null } },
    }),
  });
  const result = await harness.api.fetchAmazonJobFeed();

  assert.equal(result.scanStatus, 'COMPLETE');
  assert.equal(harness.amazonCalls.length, 1);
  const { url, options, body } = harness.amazonCalls[0];
  assert.equal(url, 'https://www.jobsatamazon.co.uk/graphql');
  assert.match(body.query, /query searchJobCardsByLocation\(\$searchJobRequest: SearchJobRequest!\)/);
  assert.match(body.query, /searchJobCardsByLocation\(searchJobRequest: \$searchJobRequest\)/);
  assert.deepEqual(JSON.parse(JSON.stringify(body.variables.searchJobRequest)), {
    locale: 'en-GB',
    country: 'United Kingdom',
    keyWords: '',
    equalFilters: [],
    containFilters: [{ key: 'isPrivateSchedule', val: ['true', 'false'] }],
    rangeFilters: [],
    orFilters: [],
    dateFilters: [],
    sorters: [{ fieldName: 'totalPayRateMax', ascending: 'false' }],
    pageSize: 100,
    consolidateSchedule: true,
  });
  assert.deepEqual(JSON.parse(JSON.stringify(options.headers)), {
    'Content-Type': 'application/json',
    Accept: 'application/json',
    'Accept-Language': 'en-GB,en;q=0.9',
    Origin: 'https://www.jobsatamazon.co.uk',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  });
});

test('Railway Amazon variables are applied to both job and schedule requests', async (t) => {
  const harness = createScannerHarness(t, {
    env: {
      AMAZON_PROXY_URL: 'http://amazon-proxy.test:8080',
      SHIFT_PROXY_URL: 'http://fallback-proxy.test:8080',
      PROXY_URL: 'http://legacy-proxy.test:8080',
      AMAZON_AUTHORIZATION: 'mock-amazon-authorization',
      AMAZON_AUTH_TOKEN: 'mock-fallback-authorization',
      AUTHORIZATION: 'mock-legacy-authorization',
    },
  });

  await harness.api.fetchAmazonJobFeed();
  await harness.api.fetchSchedulesForJob(jobSource.jobId);

  assert.equal(harness.amazonCalls.length, 2);
  for (const { options } of harness.amazonCalls) {
    assert.equal(options.dispatcher.url, 'http://amazon-proxy.test:8080');
    assert.equal(options.headers.Authorization, 'mock-amazon-authorization');
  }
});

test('legacy proxy and authorization environment-variable fallbacks remain supported', async (t) => {
  const firstFallbackHarness = createScannerHarness(t, {
    env: {
      SHIFT_PROXY_URL: 'http://shift-proxy.test:8080',
      PROXY_URL: 'http://legacy-proxy.test:8080',
      AMAZON_AUTH_TOKEN: 'mock-amazon-token',
      AUTHORIZATION: 'mock-legacy-authorization',
    },
  });
  await firstFallbackHarness.api.fetchAmazonJobFeed();
  await firstFallbackHarness.api.fetchSchedulesForJob(jobSource.jobId);

  for (const { options } of firstFallbackHarness.amazonCalls) {
    assert.equal(options.dispatcher.url, 'http://shift-proxy.test:8080');
    assert.equal(options.headers.Authorization, 'mock-amazon-token');
  }

  const finalFallbackHarness = createScannerHarness(t, {
    env: {
      PROXY_URL: 'http://legacy-proxy.test:8080',
      AUTHORIZATION: 'mock-legacy-authorization',
    },
  });
  await finalFallbackHarness.api.fetchAmazonJobFeed();
  await finalFallbackHarness.api.fetchSchedulesForJob(jobSource.jobId);

  for (const { options } of finalFallbackHarness.amazonCalls) {
    assert.equal(options.dispatcher.url, 'http://legacy-proxy.test:8080');
    assert.equal(options.headers.Authorization, 'mock-legacy-authorization');
  }
});

test('HTTP-success job responses with GraphQL errors are logged and marked PARTIAL', async (t) => {
  const logs = [];
  const harness = createScannerHarness(t, {
    jobResponder: async () => mockResponse({
      errors: [{ message: 'Invalid SearchJobRequest; authorization=mock-secret' }],
      data: {
        searchJobCardsByLocation: {
          jobCards: [jobSource],
          nextToken: null,
        },
      },
    }),
    logger: {
      log() {},
      warn: (...values) => logs.push(values.join(' ')),
      error: (...values) => logs.push(values.join(' ')),
    },
  });

  const result = await harness.api.fetchAmazonJobFeed();
  assert.equal(result.scanStatus, 'PARTIAL');
  assert.equal(result.jobCards.length, 1);
  assert.ok(logs.some((line) => line.includes('Amazon GraphQL job feed errors')));
  assert.ok(logs.some((line) => line.includes('Invalid SearchJobRequest')));
  assert.doesNotMatch(logs.join('\n'), /mock-secret/);
  assert.deepEqual(harness.delays, []);
});

test('job-feed HTTP 403 and 429 responses are logged with status details', async (t) => {
  const logs = [];
  const logger = {
    log() {},
    warn: (...values) => logs.push(values.join(' ')),
    error: (...values) => logs.push(values.join(' ')),
  };
  const blockedHarness = createScannerHarness(t, {
    jobResponder: async () => mockResponse({}, 403),
    logger,
  });
  const blocked = await blockedHarness.api.fetchAmazonJobFeed();
  assert.equal(blocked.scanStatus, 'BLOCKED');
  assert.ok(logs.some((line) => line.includes('BLOCKED: Amazon HTTP 403 on job feed page 1')));
  assert.deepEqual(blockedHarness.delays, []);

  logs.length = 0;
  const throttledHarness = createScannerHarness(t, {
    jobResponder: async () => mockResponse({}, 429, { 'Retry-After': '45' }),
    logger,
  });
  const throttled = await throttledHarness.api.fetchAmazonJobFeed();
  assert.equal(throttled.scanStatus, 'PARTIAL');
  assert.ok(logs.some((line) => (
    line.includes('THROTTLED: Amazon HTTP 429 on job feed page 1')
    && line.includes('Retry-After=45')
  )));
  assert.deepEqual(throttledHarness.delays, []);
});

test('job pagination with an unconsumed nextToken is reported PARTIAL at the page limit', async (t) => {
  const harness = createScannerHarness(t, {
    jobResponder: async (_call, page) => mockResponse({
      data: {
        searchJobCardsByLocation: {
          jobCards: [],
          nextToken: `job-page-${page + 1}`,
        },
      },
    }),
  });

  const result = await harness.api.fetchAmazonJobFeed();
  assert.equal(harness.amazonCalls.length, 10);
  assert.equal(result.scanStatus, 'PARTIAL');
  assert.deepEqual(
    harness.amazonCalls.map(({ body }) => body.variables.searchJobRequest.nextToken ?? null),
    [null, ...Array.from({ length: 9 }, (_, index) => `job-page-${index + 2}`)],
  );
});

test('schedule pagination with an unconsumed nextToken is reported incomplete', async (t) => {
  const harness = createScannerHarness(t, {
    scheduleResponder: async (_call, page) => mockResponse({
      data: {
        searchScheduleCards: {
          scheduleCards: [],
          nextToken: `schedule-page-${page + 1}`,
        },
      },
    }),
  });

  const result = await harness.api.fetchSchedulesForJob(jobSource.jobId);
  assert.equal(harness.amazonCalls.length, 5);
  assert.equal(result.paginationComplete, false);
  assert.equal(result.schedules.length, 0);
  assert.deepEqual(
    harness.amazonCalls.map(({ body }) => body.variables.searchScheduleRequest.nextToken ?? null),
    [null, 'schedule-page-2', 'schedule-page-3', 'schedule-page-4', 'schedule-page-5'],
  );
});

test('HTTP-success schedule responses with GraphQL errors are logged and incomplete', async (t) => {
  const logs = [];
  const harness = createScannerHarness(t, {
    scheduleResponder: async () => mockResponse({
      errors: [{ message: 'Schedule selection failed; token=mock-secret' }],
      data: {
        searchScheduleCards: {
          scheduleCards: [{ scheduleId: 'S-PARTIAL', jobId: jobSource.jobId }],
          nextToken: null,
        },
      },
    }),
    logger: {
      log() {},
      warn: (...values) => logs.push(values.join(' ')),
      error: (...values) => logs.push(values.join(' ')),
    },
  });

  const result = await harness.api.fetchSchedulesForJob(jobSource.jobId);
  assert.equal(result.paginationComplete, false);
  assert.equal(result.schedules.length, 1);
  assert.ok(logs.some((line) => line.includes('Amazon GraphQL schedule feed errors')));
  assert.ok(logs.some((line) => line.includes('Schedule selection failed')));
  assert.doesNotMatch(logs.join('\n'), /mock-secret/);
});

test('schedule HTTP 403 and 429 responses are logged with status details', async (t) => {
  const logs = [];
  const logger = {
    log() {},
    warn: (...values) => logs.push(values.join(' ')),
    error: (...values) => logs.push(values.join(' ')),
  };
  const blockedHarness = createScannerHarness(t, {
    scheduleResponder: async () => mockResponse({}, 403),
    logger,
  });
  const blocked = await blockedHarness.api.fetchSchedulesForJob(jobSource.jobId);
  assert.equal(blocked.paginationComplete, false);
  assert.ok(logs.some((line) => (
    line.includes(`BLOCKED: Amazon HTTP 403 on schedule feed page 1 for job ${jobSource.jobId}`)
  )));

  logs.length = 0;
  const throttledHarness = createScannerHarness(t, {
    scheduleResponder: async () => mockResponse({}, 429, { 'retry-after': '30' }),
    logger,
  });
  const throttled = await throttledHarness.api.fetchSchedulesForJob(jobSource.jobId);
  assert.equal(throttled.paginationComplete, false);
  assert.equal(throttled.failureStatus, 'THROTTLED');
  assert.ok(logs.some((line) => (
    line.includes(`THROTTLED: Amazon HTTP 429 on schedule feed page 1 for job ${jobSource.jobId}`)
    && line.includes('Retry-After=30')
  )));
});

test('an incomplete schedule scan cannot be reported as COMPLETE', async (t) => {
  const logs = [];
  const harness = createScannerHarness(t, {
    jobResponder: async (_call, page) => {
      if (page > 1) throw new Error('stop after one offline scan');
      return mockResponse({
        data: {
          searchJobCardsByLocation: {
            jobCards: [jobSource],
            nextToken: null,
          },
        },
      });
    },
    scheduleResponder: async () => mockResponse({
      data: {
        searchScheduleCards: {
          scheduleCards: [],
          nextToken: 'still-more-schedules',
        },
      },
    }),
    timeoutHandler(milliseconds) {
      if (milliseconds < 10000) throw new Error('stop after scan status');
      if (milliseconds === 10000) throw new Error('stop loop after status log');
    },
    logger: {
      log: (...values) => logs.push(values.join(' ')),
      warn: (...values) => logs.push(values.join(' ')),
      error: (...values) => logs.push(values.join(' ')),
    },
  });
  await assert.rejects(harness.api.runScannerLoop('Loop-test'), /stop loop after status log/);
  assert.ok(logs.some((line) => line.includes('status: [PARTIAL]')));
  assert.equal(logs.some((line) => line.includes('status: [COMPLETE]')), false);
});

test('schedule pagination status helper keeps blocked and partial states', async (t) => {
  const harness = createScannerHarness(t);
  assert.equal(harness.api.includeSchedulePaginationStatus('COMPLETE', false), 'PARTIAL');
  assert.equal(harness.api.includeSchedulePaginationStatus('PARTIAL', false), 'PARTIAL');
  assert.equal(harness.api.includeSchedulePaginationStatus('BLOCKED', false), 'BLOCKED');
  assert.equal(harness.api.includeSchedulePaginationStatus('COMPLETE', false, 'THROTTLED'), 'THROTTLED');
});

test('Amazon requests add a finite timeout without changing their connection settings', async (t) => {
  const harness = createScannerHarness(t);
  await harness.api.fetchAmazonJobFeed();

  const { options } = harness.amazonCalls[0];
  assert.ok(options.signal instanceof AbortSignal);
  assert.equal(options.method, 'POST');
  assert.ok(options.dispatcher === undefined);
  assert.equal(harness.api.AMAZON_REQUEST_TIMEOUT_MS, 30_000);
});

test('HTTP 403 opens one shared 15-minute cooldown for job and schedule requests', async (t) => {
  const logs = [];
  const harness = createScannerHarness(t, {
    jobResponder: async () => mockResponse({}, 403),
    logger: {
      log: (...values) => logs.push(values.join(' ')),
      warn: (...values) => logs.push(values.join(' ')),
      error: (...values) => logs.push(values.join(' ')),
    },
  });

  const first = await harness.api.fetchAmazonJobFeed();
  assert.equal(first.scanStatus, 'BLOCKED');
  assert.equal(harness.amazonCalls.length, 1);

  const schedules = await harness.api.fetchSchedulesForJob(jobSource.jobId);
  assert.equal(schedules.paginationComplete, false);
  assert.equal(harness.amazonCalls.length, 1, 'schedule request must not reach Amazon during cooldown');

  const second = await harness.api.fetchAmazonJobFeed();
  assert.equal(second.scanStatus, 'BLOCKED');
  assert.equal(harness.amazonCalls.length, 1, 'other scanner loops must share the same cooldown');

  const control = harness.api.db.prepare(
    'SELECT cooldown_until_ms, cooldown_reason FROM amazon_request_control WHERE id = 1',
  ).get();
  assert.equal(control.cooldown_reason, 'HTTP 403');
  assert.ok(control.cooldown_until_ms > Date.now() + (14 * 60 * 1000));
  assert.ok(logs.some((line) => line.includes('[Amazon Protection] HTTP 403')));
});

test('HTTP 429 honours Retry-After and blocks all subsequent Amazon requests', async (t) => {
  const harness = createScannerHarness(t, {
    jobResponder: async () => mockResponse({}, 429, { 'Retry-After': '45' }),
  });

  const first = await harness.api.fetchAmazonJobFeed();
  assert.equal(first.scanStatus, 'THROTTLED');
  assert.equal(harness.amazonCalls.length, 1);

  const second = await harness.api.fetchSchedulesForJob(jobSource.jobId);
  assert.equal(second.paginationComplete, false);
  assert.equal(harness.amazonCalls.length, 1);

  const control = harness.api.db.prepare(
    'SELECT cooldown_until_ms, cooldown_reason FROM amazon_request_control WHERE id = 1',
  ).get();
  assert.equal(control.cooldown_reason, 'HTTP 429');
  assert.ok(control.cooldown_until_ms >= Date.now() + 40_000);
});

test('Retry-After supports HTTP dates and falls back safely when invalid', (t) => {
  const harness = createScannerHarness(t);
  const now = Date.now();
  assert.equal(harness.api.parseAmazonRetryAfter('60', now), now + 60_000);
  assert.equal(
    harness.api.parseAmazonRetryAfter(new Date(now + 90_000).toUTCString(), now),
    Date.parse(new Date(now + 90_000).toUTCString()),
  );
  assert.equal(
    harness.api.parseAmazonRetryAfter('not-a-date', now),
    now + 60_000,
  );
});

test('job cards from successful pages are retained when a later page is blocked', async (t) => {
  const harness = createScannerHarness(t, {
    jobResponder: async (_call, page) => {
      if (page === 1) {
        return mockResponse({
          data: {
            searchJobCardsByLocation: {
              jobCards: [jobSource],
              nextToken: 'next-page',
            },
          },
        });
      }
      return mockResponse({}, 403);
    },
  });

  const result = await harness.api.fetchAmazonJobFeed();
  assert.equal(result.scanStatus, 'BLOCKED');
  assert.equal(result.jobCards.length, 1);
  assert.equal(result.jobCards[0].jobId, jobSource.jobId);
});
