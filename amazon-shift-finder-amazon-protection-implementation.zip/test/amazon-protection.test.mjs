import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';
import test from 'node:test';

function createProtectionHarness({ responseStatus = 200, retryAfter = null, fetchError = null } = {}) {
  const sourcePath = fileURLToPath(new URL('../tracker.mjs', import.meta.url));
  const source = readFileSync(sourcePath, 'utf8');
  const start = source.indexOf('// Amazon request protection is deliberately conservative:');
  const end = source.indexOf('let telegramWorkerRunning = false;', start);
  assert.ok(start >= 0 && end > start, 'Amazon protection implementation must exist');
  const implementation = source.slice(start, end);
  let storedCooldown = { cooldown_until_ms: 0, cooldown_reason: null };
  const calls = [];
  const logs = [];
  const response = {
    status: responseStatus,
    headers: { get: (name) => name.toLowerCase() === 'retry-after' ? retryAfter : null },
  };
  const context = vm.createContext({
    Date,
    AbortSignal,
    Promise,
    Error,
    Math,
    Number,
    String,
    RegExp,
    fetch: async (url, options) => {
      calls.push({ url, options });
      if (fetchError) throw fetchError;
      return response;
    },
    stmtGetAmazonCooldown: { get: () => ({ ...storedCooldown }) },
    stmtSetAmazonCooldown: { run: (until, reason) => {
      storedCooldown = { cooldown_until_ms: until, cooldown_reason: reason };
    } },
    console: {
      log: (...args) => logs.push(args.join(' ')),
      warn: (...args) => logs.push(args.join(' ')),
    },
  });
  vm.runInContext(`${implementation}\nglobalThis.protection = { fetchAmazon, parseAmazonRetryAfter, AMAZON_REQUEST_TIMEOUT_MS };`, context);
  return { api: context.protection, calls, logs, getCooldown: () => storedCooldown };
}

test('403 pauses all later Amazon requests for 15 minutes', async () => {
  const harness = createProtectionHarness({ responseStatus: 403 });
  const options = { method: 'POST', headers: { Accept: 'application/json' }, body: '{"query":"unchanged"}', dispatcher: { marker: true } };
  const response = await harness.api.fetchAmazon('https://www.jobsatamazon.co.uk/graphql', options);
  assert.equal(response.status, 403);
  assert.equal(harness.calls.length, 1);
  assert.equal(harness.calls[0].options.method, 'POST');
  assert.deepEqual(harness.calls[0].options.headers, options.headers);
  assert.equal(harness.calls[0].options.body, options.body);
  assert.equal(harness.calls[0].options.dispatcher, options.dispatcher);
  assert.ok(harness.calls[0].options.signal instanceof AbortSignal);
  assert.equal(harness.api.AMAZON_REQUEST_TIMEOUT_MS, 30_000);
  const cooldown = harness.getCooldown();
  assert.equal(cooldown.cooldown_reason, 'HTTP 403');
  assert.ok(cooldown.cooldown_until_ms > Date.now() + 14 * 60 * 1000);
  await assert.rejects(
    harness.api.fetchAmazon('https://www.jobsatamazon.co.uk/graphql', options),
    (error) => error.status === 403 && error.name === 'AmazonRequestPausedError',
  );
  assert.equal(harness.calls.length, 1, 'no second request should be sent during the cooldown');
});

test('429 honours Retry-After and pauses all later Amazon requests', async () => {
  const harness = createProtectionHarness({ responseStatus: 429, retryAfter: '45' });
  await harness.api.fetchAmazon('https://www.jobsatamazon.co.uk/graphql', { method: 'POST' });
  assert.equal(harness.getCooldown().cooldown_reason, 'HTTP 429');
  assert.ok(harness.getCooldown().cooldown_until_ms >= Date.now() + 40_000);
  await assert.rejects(
    harness.api.fetchAmazon('https://www.jobsatamazon.co.uk/graphql', { method: 'POST' }),
    (error) => error.status === 429,
  );
  assert.equal(harness.calls.length, 1);
});

test('Retry-After accepts seconds and HTTP dates, with a 60-second invalid-header fallback', () => {
  const harness = createProtectionHarness();
  const now = Date.now();
  assert.equal(harness.api.parseAmazonRetryAfter('30', now), now + 30_000);
  const date = new Date(now + 90_000).toUTCString();
  assert.equal(harness.api.parseAmazonRetryAfter(date, now), Date.parse(date));
  assert.equal(harness.api.parseAmazonRetryAfter('invalid', now), now + 60_000);
});


test('transient HTTP 5xx and network errors pause all loops briefly instead of retrying immediately', async () => {
  const serverFailure = createProtectionHarness({ responseStatus: 503 });
  await serverFailure.api.fetchAmazon('https://www.jobsatamazon.co.uk/graphql', { method: 'POST' });
  assert.equal(serverFailure.getCooldown().cooldown_reason, 'HTTP 503');
  await assert.rejects(
    serverFailure.api.fetchAmazon('https://www.jobsatamazon.co.uk/graphql', { method: 'POST' }),
    (error) => error.status === 503,
  );
  assert.equal(serverFailure.calls.length, 1);

  const networkFailure = createProtectionHarness({ fetchError: new TypeError('connection reset') });
  await assert.rejects(
    networkFailure.api.fetchAmazon('https://www.jobsatamazon.co.uk/graphql', { method: 'POST' }),
    /connection reset/,
  );
  assert.equal(networkFailure.getCooldown().cooldown_reason, 'NETWORK ERROR');
  await assert.rejects(
    networkFailure.api.fetchAmazon('https://www.jobsatamazon.co.uk/graphql', { method: 'POST' }),
    (error) => error.status === 503,
  );
  assert.equal(networkFailure.calls.length, 1);
});
