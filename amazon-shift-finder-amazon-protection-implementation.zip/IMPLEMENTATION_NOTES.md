# Amazon Shift Finder — Amazon connection protection implementation

## Scope

This is a development-only source change based on the uploaded source audit ZIP. It does not modify Railway production, Git branches, credentials, Amazon account settings, or live services.

## Changes in `tracker.mjs`

- Routes both Amazon GraphQL request paths through one `fetchAmazon()` wrapper.
- Adds a 30-second request timeout using `AbortSignal.timeout()`.
- Adds a shared, SQLite-persisted 15-minute cooldown after HTTP 403.
- Adds a shared cooldown after HTTP 429, honouring `Retry-After` as seconds or an HTTP date; uses 60 seconds when the header is absent or invalid.
- Adds a 30-second shared cooldown after HTTP 408, HTTP 5xx, network errors, or request timeouts.
- Prevents all three scanner loops from continuing to send Amazon requests while the shared cooldown is active. Loops wait in intervals of up to 60 seconds and resume after expiry.
- Does not automatically retry failed Amazon requests, rotate proxies, or fall back from the configured proxy.
- Carries schedule-feed failure status into the overall scan status so throttling and blocking are visible.

## Amazon connection settings deliberately preserved

The following remain unchanged from the uploaded source:

- GraphQL endpoint URLs and operation/query strings.
- Request methods, JSON bodies, variables, pagination tokens and page limits.
- All existing request headers and Authorization resolution.
- Existing `ProxyAgent` construction and dispatcher selection.
- Three scanner loops and their 0/5/10-second startup staggering.
- Existing 3–5 second normal scan-cycle jitter.
- SQLite schedule records and Telegram outbox schema/data; the only database addition is the new `amazon_request_control` table.

The timeout signal is the only request-option addition.

## Tests and verification

- `node --check` passed for `tracker.mjs` and all test files.
- The four standalone Amazon-protection unit tests passed.
- Static comparison confirmed the GraphQL query strings and original Amazon request method, headers, body and proxy dispatcher options are unchanged.
- The complete existing test suite could not be executed in this container because `node_modules` is absent and `better-sqlite3` is not installed. The existing integration tests and the added integration cases must still be run in the Replit development environment with dependencies installed.
- No live Amazon requests were made.

## Deployment status

Not deployed. No Git commit or push was made. Production was not changed.
