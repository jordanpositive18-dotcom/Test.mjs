Test.mjs is preserved at the repository root for original path fidelity. This identical copy identifies it as the legacy/alternate script. package.json starts the application with tracker.mjs.
